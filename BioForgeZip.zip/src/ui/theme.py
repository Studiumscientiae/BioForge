



"""
Central UI theme configuration for BioForge.
"""

# Sidebar
SIDEBAR_WIDTH = 220
SIDEBAR_CORNER_RADIUS = 12

# Navigation Buttons
NAV_BUTTON_HEIGHT = 40
NAV_BUTTON_CORNER_RADIUS = 8

ACTIVE_BUTTON_COLOR = ("gray70", "gray30")
INACTIVE_BUTTON_COLOR = ("gray25", "gray25")

# Fonts
TITLE_FONT_SIZE = 24
SUBTITLE_FONT_SIZE = 12
FOOTER_FONT_SIZE = 12

# Spacing
DEFAULT_PADDING = 10
SECTION_PADDING = 15